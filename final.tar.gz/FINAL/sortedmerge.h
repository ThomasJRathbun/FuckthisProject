#ifndef SORTEDMERGE_H
#define SORTEDMERGE_H

#include "mergesort.h"

//merges sorted lists
node* sortedMerge( node*,  node*, int, int (*)(void*,void*) );


#endif
